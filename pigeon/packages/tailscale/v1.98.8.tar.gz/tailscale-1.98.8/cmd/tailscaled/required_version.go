// Copyright (c) Tailscale Inc & contributors
// SPDX-License-Identifier: BSD-3-Clause

//go:build !go1.23

package main

func init() {
	you_need_Go_1_23_to_compile_Tailscale()
}
