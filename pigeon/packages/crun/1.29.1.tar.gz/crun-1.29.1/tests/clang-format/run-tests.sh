#!/bin/bash

set -e -x

cd /crun

# Recent git complains that the directory is owned by someone else,
# which happens if we run it via a Dockerfile with a volume mounted.
git config --global --add safe.directory "$(pwd)"

./configure --enable-embedded-blake3
make clang-format
git diff --ignore-submodules --exit-code
