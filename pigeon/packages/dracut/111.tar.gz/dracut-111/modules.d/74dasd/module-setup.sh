#!/bin/bash

# called by dracut
check() {
    [ "$DRACUT_ARCH" = "s390" ] || [ "$DRACUT_ARCH" = "s390x" ] || return 1
    require_binaries dasdconf.sh || return 1
    return 0
}

# called by dracut
install() {
    inst_multiple dasdconf.sh
    conf=/etc/dasd.conf
    if [[ $hostonly && -f $conf ]]; then
        inst -H $conf
    fi
    inst_rules 56-dasd.rules 59-dasd.rules
}
