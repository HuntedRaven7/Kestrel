#!/bin/bash
# This file is part of dracut.
# SPDX-License-Identifier: GPL-2.0-or-later

# Prerequisite check(s) for module.
check() {

    # If the binary(s) requirements are not fulfilled the module can't be installed.
    require_binaries pcscd || return 1

    # Return 255 to only include the module, if another module requires it.
    return 255

}

# Module dependency requirements.
depends() {

    # This module has external dependency on other module(s).
    echo systemd-udevd
    # Return 0 to include the dependent module(s) in the initramfs.
    return 0

}

# Install the required file(s) and directories for the module in the initramfs.
install() {
    inst_simple "$moddir/pcscd.service" "${systemdsystemunitdir}"/pcscd.service
    inst_simple "$moddir/pcscd.socket" "${systemdsystemunitdir}"/pcscd.socket

    inst_multiple -o \
        pcscd \
        /etc/pkcs11/modules/opensc.module \
        /usr/share/p11-kit/modules/opensc.module \
        /usr/share/p11-kit/modules/opensc-pkcs11.module

    # Enable systemd type unit(s)
    for i in \
        pcscd.service \
        pcscd.socket; do
        $SYSTEMCTL -q --root "$initdir" enable "$i"
    done

    # Install library file(s)
    inst_libdir_file \
        {"tls/$DRACUT_ARCH/",tls/,"$DRACUT_ARCH/",}"libopensc.so.*" \
        {"tls/$DRACUT_ARCH/",tls/,"$DRACUT_ARCH/",}"libsmm-local.so.*" \
        {"tls/$DRACUT_ARCH/",tls/,"$DRACUT_ARCH/",}"opensc-pkcs11.so" \
        {"tls/$DRACUT_ARCH/",tls/,"$DRACUT_ARCH/",}"onepin-opensc-pkcs11.so" \
        {"tls/$DRACUT_ARCH/",tls/,"$DRACUT_ARCH/",}"pkcs11/opensc-pkcs11.so" \
        {"tls/$DRACUT_ARCH/",tls/,"$DRACUT_ARCH/",}"pkcs11/onepin-opensc-pkcs11.so" \
        {"tls/$DRACUT_ARCH/",tls/,"$DRACUT_ARCH/",}"pcsc/drivers/ifd-ccid.bundle/Contents/Info.plist" \
        {"tls/$DRACUT_ARCH/",tls/,"$DRACUT_ARCH/",}"pcsc/drivers/ifd-ccid.bundle/Contents/Linux/libccid.so" \
        {"tls/$DRACUT_ARCH/",tls/,"$DRACUT_ARCH/",}"pcsc/drivers/serial/libccidtwin.so" \
        {"tls/$DRACUT_ARCH/",tls/,"$DRACUT_ARCH/",}"libeac.so*" \
        {"tls/$DRACUT_ARCH/",tls/,"$DRACUT_ARCH/",}"libpcsclite.so.*" \
        {"tls/$DRACUT_ARCH/",tls/,"$DRACUT_ARCH/",}"libpcsclite_real.so.*"

    # Install the hosts local user configurations if enabled.
    if [[ $hostonly ]]; then
        inst_multiple -H -o \
            /etc/opensc.conf \
            /etc/opensc/opensc.conf \
            "/etc/reader.conf.d/*"
    fi

}
