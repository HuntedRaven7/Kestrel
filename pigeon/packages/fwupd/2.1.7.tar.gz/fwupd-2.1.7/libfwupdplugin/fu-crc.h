/*
 * Copyright 2017 Richard Hughes <richard@hughsie.com>
 *
 * SPDX-License-Identifier: LGPL-2.1-or-later
 */

#pragma once

#include <fwupd.h>

#include "fu-crc-struct.h"

guint
fu_crc_size(FuCrcKind kind);

guint32
fu_crc32(FuCrcKind kind, const guint8 *buf, gsize bufsz);
gboolean
fu_crc32_safe(FuCrcKind kind,
	      const guint8 *buf,
	      gsize bufsz,
	      gsize offset,
	      gsize n,
	      guint32 *value,
	      GError **error) G_GNUC_WARN_UNUSED_RESULT G_GNUC_NON_NULL(2);
guint32
fu_crc32_bytes(FuCrcKind kind, GBytes *blob);
guint16
fu_crc16(FuCrcKind kind, const guint8 *buf, gsize bufsz);
gboolean
fu_crc16_safe(FuCrcKind kind,
	      const guint8 *buf,
	      gsize bufsz,
	      gsize offset,
	      gsize n,
	      guint16 *value,
	      GError **error) G_GNUC_WARN_UNUSED_RESULT G_GNUC_NON_NULL(2);
guint16
fu_crc16_bytes(FuCrcKind kind, GBytes *blob);
guint8
fu_crc8(FuCrcKind kind, const guint8 *buf, gsize bufsz);
gboolean
fu_crc8_safe(FuCrcKind kind,
	     const guint8 *buf,
	     gsize bufsz,
	     gsize offset,
	     gsize n,
	     guint8 *value,
	     GError **error) G_GNUC_WARN_UNUSED_RESULT G_GNUC_NON_NULL(2);
guint8
fu_crc8_bytes(FuCrcKind kind, GBytes *blob);

gboolean
fu_crc_find(const guint8 *buf, gsize bufsz, guint32 crc_target, FuCrcKind *kind, GError **error);

guint16
fu_crc_misr16(guint16 init, const guint8 *buf, gsize bufsz);
